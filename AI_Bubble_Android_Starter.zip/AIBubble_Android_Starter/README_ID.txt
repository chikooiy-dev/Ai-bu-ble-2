AI Bubble — proyek starter Android

Yang tersedia:
- Ikon AI kecil yang dapat digeser.
- Menu mengambang untuk membuka ChatGPT atau Gemini melalui browser.
- Meminta izin overlay Android secara standar.

Belum tersedia:
- APK siap instal.
- Pemindaian layar/OCR dan pengiriman teks ke AI.
- Jendela chat AI yang tertanam di overlay.

Cara membuat APK:
1. Ekstrak ZIP ini.
2. Buka folder proyek di Android Studio pada komputer.
3. Tunggu Gradle Sync (internet diperlukan untuk mengunduh komponen build).
4. Pilih Build > Build APK(s).
5. Untuk pengujian pribadi, instal APK debug yang dihasilkan.

Catatan: aplikasi memakai izin overlay yang terlihat pada pengaturan Android. Proyek ini tidak menyamarkan aktivitas aplikasi atau menghindari sistem deteksi. Fitur scan layar memerlukan implementasi MediaProjection dengan persetujuan sistem dan OCR.
