package com.example.aibubble

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28); setBackgroundColor(Color.rgb(248, 246, 252))
        }
        val title = TextView(this).apply { text = "AI Bubble"; textSize = 28f; setTextColor(Color.rgb(45, 35, 65)); gravity = Gravity.CENTER }
        val info = TextView(this).apply {
            text = "Ikon AI mengambang untuk membuka ChatGPT atau Gemini.\n\nIzin overlay diperlukan agar tombol tampil di atas aplikasi lain."
            textSize = 16f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(0, 20, 0, 24)
        }
        val start = Button(this).apply {
            text = "Aktifkan ikon AI"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, BubbleService::class.java)); finish()
                }
            }
        }
        val note = TextView(this).apply {
            text = "Versi starter: membuka AI melalui browser. Fitur scan layar/OCR belum tersedia."
            textSize = 13f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(0, 22, 0, 0)
        }
        layout.addView(title); layout.addView(info); layout.addView(start); layout.addView(note)
        setContentView(layout)
    }
}
