package com.example.aibubble

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.net.Uri

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager; showBubble() }
    private fun overlayType() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
    private fun params(width: Int, height: Int) = WindowManager.LayoutParams(width, height, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 220 }
    private fun showBubble() {
        val b = TextView(this).apply {
            text = "AI"; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(103, 80, 164)); elevation = 10f; setPadding(16, 12, 16, 12); contentDescription = "Buka menu AI"
        }
        val p = params(64, 56); var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        b.setOnTouchListener { _, event -> when (event.action) {
            MotionEvent.ACTION_DOWN -> { startX = p.x; startY = p.y; touchX = event.rawX; touchY = event.rawY; true }
            MotionEvent.ACTION_MOVE -> { p.x = startX + (event.rawX-touchX).toInt(); p.y = startY + (event.rawY-touchY).toInt(); wm.updateViewLayout(b,p); true }
            MotionEvent.ACTION_UP -> { if (kotlin.math.abs(event.rawX-touchX) < 8 && kotlin.math.abs(event.rawY-touchY) < 8) togglePanel(); true }
            else -> false
        } }
        bubble = b; wm.addView(b,p)
    }
    private fun togglePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {}; panel = null; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,16,18,16); setBackgroundColor(Color.rgb(250,248,255)); elevation = 16f }
        box.addView(TextView(this).apply { text = "Pilih AI"; textSize = 18f; setTextColor(Color.rgb(45,35,65)); setPadding(0,0,0,10) })
        box.addView(actionButton("Buka ChatGPT") { openUrl("https://chatgpt.com") })
        box.addView(actionButton("Buka Gemini") { openUrl("https://gemini.google.com") })
        box.addView(actionButton("Tutup menu") { togglePanel() })
        val p = params(240, WindowManager.LayoutParams.WRAP_CONTENT).apply { x = 100; y = 220 }
        panel = box; wm.addView(box,p)
    }
    private fun actionButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 15f; setTextColor(Color.rgb(45,35,65)); setPadding(10,14,10,14); setOnClickListener { action() }
    }
    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null
    }
    override fun onDestroy() { bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null; panel = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
